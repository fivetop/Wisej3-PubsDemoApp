﻿Imports System
Imports Wisej.Web
Imports System.ComponentModel
Imports System.ComponentModel.Design

Public Class BasicDALTextBox

End Class
